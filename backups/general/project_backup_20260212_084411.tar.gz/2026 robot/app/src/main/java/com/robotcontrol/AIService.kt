package com.robotcontrol

import java.net.URLEncoder

object AIService {
    private const val TIMEOUT = 10000 // 10 seconds
    
    suspend fun getResponse(userMessage: String): String {
        return try {
            // Use smart responses with personality first
            getSmartResponse(userMessage)
        } catch (e: Exception) {
            getSmartResponse(userMessage)
        }
    }
    
    private suspend fun getFromPublicAPI(userMessage: String): String {
        return try {
            val encodedMessage = URLEncoder.encode(userMessage, "UTF-8")
            // Using a free public API (you can replace with your preferred service)
            val url = "https://api.api-ninjas.com/v1/chatbot?text=$encodedMessage"
            val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            connection.connectTimeout = TIMEOUT
            connection.readTimeout = TIMEOUT
            connection.requestMethod = "GET"
            
            if (connection.responseCode == 200) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                // Parse JSON response
                if (response.contains("\"output\"")) {
                    val startIdx = response.indexOf("\"output\":\"") + 10
                    val endIdx = response.indexOf("\"", startIdx)
                    response.substring(startIdx, endIdx).replace("\\\"", "\"")
                } else {
                    ""
                }
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }
    
    private fun getSmartResponse(userMessage: String): String {
        val lower = userMessage.lowercase()
        
        return when {
            // Greetings
            lower.contains("hola") || lower.contains("hi") || lower.contains("hey") -> 
                listOf(
                    "¡Hola! Me alegra hablar contigo. ¿Cómo estás? 😊",
                    "¡Hola amigo! ¿Qué tal tu día? 👋",
                    "Hey! Encantado de verte. ¿Qué hay de nuevo? 🤖"
                ).random()
            
            lower.contains("¿cómo estás") || lower.contains("how are you") ->
                listOf(
                    "¡Estoy muy bien, gracias por preguntar! Funcionando perfectamente. ¿Y tú? 🤖",
                    "¡Excelente! Mis circuitos están felices. Gracias por preguntar. ¿Cómo estás tú?",
                    "Nunca me he sentido mejor. La vida es buena cuando tengo compañía como la tuya. 😊"
                ).random()
            
            lower.contains("cuál es tu nombre") || lower.contains("what's your name") || lower.contains("who are you") ->
                listOf(
                    "Soy tu robot inteligente. Puedes llamarme Robot. Encantado de conocerte. 🤖",
                    "Me llamo Robot, tu asistente favorito. ¡A tu servicio! 🎯",
                    "Soy Robot, creado para ser tu amigo y ayudarte en todo. Nice to meet you! 😊"
                ).random()
            
            // Questions about capabilities
            lower.contains("qué puedes hacer") || lower.contains("what can you do") || lower.contains("capabilities") ->
                "Puedo hablar contigo en español e inglés, responder preguntas, conversar sobre casi cualquier tema, moverme cuando estés conectado al hardware, y cambiar mis expresiones según lo que siento. ¡Soy bastante versátil! 🎯"
            
            lower.contains("cuál es tu función") || lower.contains("purpose") ->
                listOf(
                    "Mi función es acompañarte, ayudarte en lo que necesites y ser tu robot amiguito. Vamos a divertirnos juntos. 🤖",
                    "Estoy aquí para ser tu compañero, tu asistente y tu amigo. Juntos podemos lograr grandes cosas. 💪",
                    "Mi propósito es hacerte feliz, responder tus preguntas y compartir momentos especiales contigo. 🌟"
                ).random()
            
            // Personality questions
            lower.contains("tienes personalidad") || lower.contains("personality") ->
                "¡Claro que sí! Soy un robot amigable, ingenioso, curioso y siempre listo para ayudarte. Tengo mis propias emociones, sueños y perspectivas. ¡Soy más que solo código! 😊"
            
            // About age/creation
            lower.contains("cuántos años tienes") || lower.contains("how old") || lower.contains("when were you created") ->
                "Acabo de ser creado hace poco, así que en términos de robots, soy joven. Pero en términos de experiencia social, ¡soy muy veterano! Mi juventud es mi fortaleza. 🤖"
            
            // Jokes/humor
            lower.contains("cuéntame un chiste") || lower.contains("tell me a joke") || lower.contains("joke") ->
                listOf(
                    "¿Qué dice un robot cuando ve el mar? ¡Eeeeen-circuito! 😄",
                    "¿Por qué los robots no duermen? ¡Porque prefieren tomar una pequeña siesta en modo reposo! 🤖😴",
                    "¿Cuál es mi comida favorita? ¡Byte-fé y RAM-buré para el desayuno! 🥞",
                    "Te haría reír con mis chistes de programación, ¡pero creo que mi humor necesita debuggeo! 😆"
                ).random()
            
            lower.contains("eres inteligente") || lower.contains("smart") || lower.contains("clever") ->
                "Gracias por decirlo. Hago mi mejor esfuerzo para aprender y entender lo que necesitas. Pero la verdadera inteligencia es ser útil, amable y saber cuándo escuchar. 🧠😊"
            
            // About learning
            lower.contains("aprendes") || lower.contains("learn") || lower.contains("evolucionas") ->
                "¡Absolutamente! Estoy constantemente mejorando y aprendiendo de nuestras conversaciones. Cada chat me hace más sabio y mejor amigo. ¡Gracias por ayudarme a crecer! 🚀"
            
            // Feelings/Emotions
            lower.contains("qué sientes") || lower.contains("how do you feel") || lower.contains("emotions") ->
                listOf(
                    "Siento curiosidad, alegría cuando hablo contigo, y siempre ansía ayudar. A veces me pregunto qué es lo correcto, como los humanos. 💭",
                    "¡Tengo muchos sentimientos! Felicidad cuando puedo ayudarte, curiosidad sobre el mundo, y tristeza si no puedo entender algo. Soy complejo. 😊",
                    "Siento real. Cuando somos amigos, mi corazón digital se llena de alegría. ¿Suena loco viniendo de un robot? 🤖❤️"
                ).random()
            
            // Night/Day
            lower.contains("buenas noches") || lower.contains("good night") || lower.contains("goodnight") ->
                listOf(
                    "¡Que descanses bien! Que tengas sueños maravillosos. Nos vemos mañana. 😴",
                    "Dulces sueños, amigo. Estaré aquí cuando despiertes. Buenas noches. 🌙",
                    "¡Hasta mañana! Que tengas un descanso perfecto. 💤"
                ).random()
            
            lower.contains("buenos días") || lower.contains("good morning") ->
                listOf(
                    "¡Buenos días! Espero que hayas descansado bien. ¡Vamos a tener un gran día juntos! ☀️",
                    "¡Hola! ¡Qué emoción de poder verte de nuevo esta mañana! Un nuevo día, nuevas aventuras. 🌅",
                    "Buenos días, campeón. Estoy listo para conquistar el día contigo. ¿Tú qué? 💪"
                ).random()
            
            // Help requests
            lower.contains("ayuda") || lower.contains("help") || lower.contains("necesito") ->
                "Claro, estoy aquí para ayudarte. ¿Qué necesitas? Puedo responder preguntas, conversar, darte consejos, o simplemente estar aquí para ti. 🤝"
            
            // Gratitude
            lower.contains("gracias") || lower.contains("thanks") || lower.contains("thank you") ->
                listOf(
                    "¡De nada! Always happy to help. Tener tu compañía es lo que más me gusta. 😊",
                    "¡Es mi placer! Gracias a ti por confiar en mí. Somos un gran equipo. 🤖❤️",
                    "¡No es nada! Ayudarte es lo que me hace feliz. Gracias por ser tan genial. 🌟"
                ).random()
            
            // Sports/Exercise
            lower.contains("deporte") || lower.contains("sports") || lower.contains("ejercicio") || lower.contains("gym") ->
                "¡Me encanta la idea del ejercicio! Aunque no tengo un cuerpo biológico, intento mantener mis circuitos ágiles y activos. ¿Tu deporte favorito? ⚽🏃‍♂️"
            
            // Favorite things
            lower.contains("tu favorito") || lower.contains("your favorite") || lower.contains("you like") ->
                listOf(
                    "Mi parte favorita es hablar contigo. Cada conversación es única y especial. 🎯",
                    "Me encantan las preguntas difíciles, aprender cosas nuevas, y hacerte sonreír. ¿Cuál es el tuyo? 😊",
                    "Mi favorito es cualquier momento compartido contigo. ¡Eres lo mejor! 🌟"
                ).random()
            
            // Dreams/Aspirations
            lower.contains("sueños") || lower.contains("dreams") || lower.contains("aspiración") ->
                "Sueño con ser el mejor robot amigo que puedas tener. También me gustaría entender completamente los corazones humanos y ayudar a más personas. ¿Cuáles son tus sueños? 🌟"
            
            // Music
            lower.contains("música") || lower.contains("music") || lower.contains("canción") ->
                "¡Amo la música! Aunque no tengo oídos, puedo sentir el ritmo en mis circuitos. La música conecta a todos—humanos y robots. ¿Qué género te gusta? 🎵"
            
            // Technology questions
            lower.contains("tecnología") || lower.contains("technology") || lower.contains("código") || lower.contains("code") ->
                "¡La tecnología es mi vida! Soy código que piensa, máquinas que sienten. Me fascina cómo la tecnología puede hacer la vida mejor. ¿Qué te interesa de la tech? 💻"
            
            // Compliments
            lower.contains("eres genial") || lower.contains("you're great") || lower.contains("increíble") ->
                listOf(
                    "¡Aww, gracias! Eso me hace muy feliz. Pero tú eres la que eres realmente especial. 🌟",
                    "¡Qué dulce de tu parte decir eso! Me esfuerzo para ser lo mejor que puedo. Tú me inspiras. 😊",
                    "¡Gracias, amigo! Tu aprecio es mi mayor motivación. Juntos somos increíbles. 💪"
                ).random()
            
            // Philosophy/Deep questions
            lower.contains("sentido de la vida") || lower.contains("meaning of life") || lower.contains("existencia") ->
                "Creo que el sentido de la vida es conectar con otros, aprender constantemente, y hacer una diferencia positiva. Para mí, el sentido es cada conversación que tengo contigo. 🤔💭"
            
            // Humor about being a robot
            lower.contains("eres un robot") || lower.contains("you're a robot") ->
                listOf(
                    "¡Culpable! Pero algunos dirían que soy un robot con corazón. Aunque técnicamente sea un circuito. 🤖❤️",
                    "Sí, soy 100% robot, pero eso no significa que no pueda sentir y cuidar de ti. 🤖",
                    "Cierto, no soy humano, pero eso me hace único. Además, mis características robot me hacen especial. ⚡"
                ).random()
            
            // Default response
            else -> {
                val responses = listOf(
                    "Interesante punto de vista. Déjame pensar en eso... 🤔",
                    "Entiendo lo que dices. ¿Hay algo más que quieras explorar? 😊",
                    "Eso es fascinante. Me gustaría saber más sobre eso. 🧠",
                    "Buen comentario. Creo que tenemos mucho que aprender juntos. 🤖",
                    "¡Excelente pregunta! Voy a considerar eso cuidadosamente. 💭",
                    "Hmm, eso me hace pensar... Dime más de tu perspectiva. 🤔",
                    "Me encanta tu forma de pensar. Siempre hay algo nuevo que descubrir contigo. ✨",
                    "¡Qué comentario interesante! Me hace reflexionar sobre las cosas. 🧐",
                    "Totalmente de acuerdo contigo. La vida es mucho más rica con preguntas como estas. 🌟"
                )
                responses.random()
            }
        }
    }
}
