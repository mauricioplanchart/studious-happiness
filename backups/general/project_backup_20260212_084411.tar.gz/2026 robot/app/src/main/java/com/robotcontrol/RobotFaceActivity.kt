package com.robotcontrol

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import java.util.*
import kotlin.math.roundToLong
import kotlin.math.sqrt

class RobotFaceActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    
    private lateinit var ivLeftEye: ImageView
    private lateinit var ivRightEye: ImageView
    private lateinit var ivMouth: ImageView
    private lateinit var tvStatus: TextView
    private lateinit var tvRobotMessage: TextView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: Button
    private lateinit var btnMicrophone: Button
    private lateinit var viewFace: View
    private lateinit var btnHappy: Button
    private lateinit var btnExcited: Button
    private lateinit var btnSurprised: Button
    private lateinit var btnAngry: Button
    
    private var currentExpression = Expression.HAPPY
    private val handler = Handler(Looper.getMainLooper())
    private var blinkRunnable: Runnable? = null
    private var mouthAnimationRunnable: Runnable? = null
    private var currentSpeechText: String = ""
    private var speechHasRangeCallbacks = false
    private var speechHasAudioCallbacks = false
    private var currentMouthOpen = 0.25f
    private val speechAudioLevels = ArrayDeque<Float>()
    
    private lateinit var textToSpeech: TextToSpeech
    private var isSpeaking = false
    
    enum class Expression {
        HAPPY, SAD, SURPRISED, ANGRY, THINKING, SLEEPING, EXCITED
    }
    
    companion object {
        const val EXTRA_EXPRESSION = "expression"
        private const val SPEECH_REQUEST_CODE = 100
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_robot_face)
        
        // Keep screen on while face is displayed
        window.decorView.keepScreenOn = true
        
        initializeViews()
        setupClickListener()
        initTextToSpeech()
        startBlinking()
        
        // Get initial expression from intent
        val expressionName = intent.getStringExtra(EXTRA_EXPRESSION) ?: "HAPPY"
        currentExpression = Expression.valueOf(expressionName)
        updateFace(currentExpression)
    }
    
    private fun initializeViews() {
        ivLeftEye = findViewById(R.id.ivLeftEye)
        ivRightEye = findViewById(R.id.ivRightEye)
        ivMouth = findViewById(R.id.ivMouth)
        tvStatus = findViewById(R.id.tvStatus)
        tvRobotMessage = findViewById(R.id.tvRobotMessage)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)
        btnMicrophone = findViewById(R.id.btnMicrophone)
        viewFace = findViewById(R.id.viewFace)
        btnHappy = findViewById(R.id.btnHappy)
        btnExcited = findViewById(R.id.btnExcited)
        btnSurprised = findViewById(R.id.btnSurprised)
        btnAngry = findViewById(R.id.btnAngry)
    }
    
    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(this, this)
        textToSpeech.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                handler.post {
                    isSpeaking = true
                    speechHasRangeCallbacks = false
                    speechHasAudioCallbacks = false
                    synchronized(speechAudioLevels) { speechAudioLevels.clear() }
                    startMouthAnimation()
                }
            }

            override fun onDone(utteranceId: String?) {
                handler.post {
                    isSpeaking = false
                    stopMouthAnimation()
                    updateFaceOnSpeechEnd()
                }
            }

            override fun onError(utteranceId: String?) {
                handler.post {
                    isSpeaking = false
                    stopMouthAnimation()
                }
            }

            override fun onRangeStart(
                utteranceId: String?,
                start: Int,
                end: Int,
                frame: Int
            ) {
                handler.post {
                    if (!isSpeaking || currentSpeechText.isEmpty() || speechHasAudioCallbacks) return@post
                    speechHasRangeCallbacks = true
                    val safeStart = start.coerceIn(0, currentSpeechText.length)
                    val safeEnd = end.coerceIn(safeStart, currentSpeechText.length)
                    val chunk = currentSpeechText.substring(safeStart, safeEnd)
                    val openness = calculateMouthOpenness(chunk)
                    animateMouthTo(openness, 65L)
                }
            }

            override fun onAudioAvailable(utteranceId: String?, audio: ByteArray?) {
                val level = extractAudioLevel(audio)
                if (level <= 0f) return

                synchronized(speechAudioLevels) {
                    if (speechAudioLevels.size >= 10) {
                        speechAudioLevels.removeFirst()
                    }
                    speechAudioLevels.addLast(level)
                }

                handler.post {
                    if (isSpeaking) {
                        speechHasAudioCallbacks = true
                    }
                }
            }
        })
    }
    
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech.setLanguage(Locale("es", "ES"))
        }
    }
    
    private fun setupClickListener() {
        // Send button
        btnSend.setOnClickListener {
            val userMessage = etMessage.text.toString().trim()
            if (userMessage.isNotEmpty()) {
                sendMessage(userMessage)
                etMessage.setText("")
            }
        }
        
        // Microphone button
        btnMicrophone.setOnClickListener {
            startSpeechRecognition()
        }
        
        // Expression buttons
        btnHappy.setOnClickListener {
            updateFace(Expression.HAPPY)
        }
        
        btnExcited.setOnClickListener {
            updateFace(Expression.EXCITED)
        }
        
        btnSurprised.setOnClickListener {
            updateFace(Expression.SURPRISED)
        }
        
        btnAngry.setOnClickListener {
            updateFace(Expression.ANGRY)
        }
        
        // Long press to go back
        viewFace.setOnLongClickListener {
            finish()
            true
        }
    }
    
    private fun startSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di algo...")
        }
        
        try {
            startActivityForResult(intent, SPEECH_REQUEST_CODE)
        } catch (e: Exception) {
            Toast.makeText(this, "Micrófono no disponible", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == SPEECH_REQUEST_CODE && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!results.isNullOrEmpty()) {
                val spokenText = results[0]
                etMessage.setText(spokenText)
                sendMessage(spokenText)
            }
        }
    }
    
    private fun sendMessage(userMessage: String) {
        btnSend.isEnabled = false
        btnMicrophone.isEnabled = false
        tvRobotMessage.text = "Pensando..."
        
        // Call AI in background
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = withContext(Dispatchers.Default) {
                    AIService.getResponse(userMessage)
                }
                
                // Update message display
                tvRobotMessage.text = response
                
                // Update robot expression based on sentiment
                updateExpressionFromResponse(response)
                
                // Speak the response
                speakResponse(response)
                
            } catch (e: Exception) {
                tvRobotMessage.text = "Perdón, algo salió mal. Intenta de nuevo."
                updateFace(Expression.SAD)
            } finally {
                btnSend.isEnabled = true
                btnMicrophone.isEnabled = true
            }
        }
    }
    
    private fun speakResponse(response: String) {
        if (::textToSpeech.isInitialized && !textToSpeech.isSpeaking) {
            // Remove emojis and clean text for speech
            val cleanText = response.replace(Regex("[^a-záéíóúñA-ZÁÉÍÓÚÑ\\s.,!?¿¡]"), "")
            
            if (cleanText.isNotEmpty()) {
                currentSpeechText = cleanText
                isSpeaking = true
                speechHasRangeCallbacks = false
                startMouthAnimation()
                
                val params = HashMap<String, String>()
                params[TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID] = "utterance1"
                textToSpeech.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params)
            }
        }
    }
    
    private fun startMouthAnimation() {
        stopMouthAnimation()
        mouthAnimationRunnable = object : Runnable {
            private var step = 0
            
            override fun run() {
                if (isSpeaking) {
                    if (speechHasAudioCallbacks) {
                        val level = pollAudioLevel()
                        if (level != null) {
                            val openness = smoothAudioMouthOpenness(level)
                            animateMouthTo(openness, 45L)
                        }
                    } else if (!speechHasRangeCallbacks) {
                        step++
                        val openness = fallbackMouthOpenness(step)
                        animateMouthTo(openness, 90L)
                    }

                    val nextTick = when {
                        speechHasAudioCallbacks -> 50L
                        speechHasRangeCallbacks -> 120L
                        else -> 110L
                    }
                    handler.postDelayed(this, nextTick)
                } else {
                    stopMouthAnimation()
                }
            }
        }
        handler.post(mouthAnimationRunnable!!)
    }
    
    private fun stopMouthAnimation() {
        mouthAnimationRunnable?.let { handler.removeCallbacks(it) }
        mouthAnimationRunnable = null
        speechHasRangeCallbacks = false
        speechHasAudioCallbacks = false
        synchronized(speechAudioLevels) { speechAudioLevels.clear() }
        currentSpeechText = ""
        currentMouthOpen = 0.25f
        
        // Reset mouth scale to normal
        ivMouth.animate().scaleY(1f).scaleX(1f).setDuration(100).start()
    }

    private fun extractAudioLevel(audio: ByteArray?): Float {
        if (audio == null || audio.size < 2) return 0f

        var sumSquares = 0.0
        var samples = 0
        var index = 0

        while (index + 1 < audio.size) {
            val low = audio[index].toInt() and 0xFF
            val high = audio[index + 1].toInt()
            val sample = (high shl 8) or low
            val signedSample = if (sample > 32767) sample - 65536 else sample
            val normalized = signedSample / 32768.0
            sumSquares += normalized * normalized
            samples++
            index += 2
        }

        if (samples == 0) return 0f
        val rms = sqrt(sumSquares / samples).toFloat()
        return (rms * 2.5f).coerceIn(0.08f, 1f)
    }

    private fun pollAudioLevel(): Float? {
        synchronized(speechAudioLevels) {
            if (speechAudioLevels.isEmpty()) return null
            return speechAudioLevels.removeFirst()
        }
    }

    private fun smoothAudioMouthOpenness(level: Float): Float {
        val target = (0.2f + (level * 0.95f)).coerceIn(0.18f, 0.98f)
        val smoothed = (currentMouthOpen * 0.2f) + (target * 0.8f)
        return (smoothed * 100f).roundToLong().toFloat() / 100f
    }

    private fun animateMouthTo(openness: Float, duration: Long) {
        currentMouthOpen = openness.coerceIn(0f, 1f)
        val scaleY = 0.75f + (currentMouthOpen * 1.2f)
        val scaleX = 1.0f + ((1f - currentMouthOpen) * 0.12f)
        ivMouth.animate()
            .scaleY(scaleY)
            .scaleX(scaleX)
            .setDuration(duration)
            .start()
    }

    private fun fallbackMouthOpenness(step: Int): Float {
        val cycle = step % 5
        return when (cycle) {
            0 -> 0.78f
            1 -> 0.48f
            2 -> 0.86f
            3 -> 0.34f
            else -> 0.6f
        }
    }

    private fun calculateMouthOpenness(chunk: String): Float {
        if (chunk.isBlank()) return 0.22f

        val vowels = chunk.count { it.lowercaseChar() in "aeiouáéíóú" }
        val punct = chunk.count { it in ".,;:!?¿¡" }
        val spaces = chunk.count { it.isWhitespace() }
        val length = chunk.length.coerceAtLeast(1)

        val vowelRatio = vowels.toFloat() / length.toFloat()
        val punctuationPenalty = if (punct > 0) 0.25f else 0f
        val pausePenalty = if (spaces == length) 0.3f else 0f

        val target = (0.3f + (vowelRatio * 0.9f) - punctuationPenalty - pausePenalty)
            .coerceIn(0.18f, 0.95f)

        val smoothed = (currentMouthOpen * 0.35f) + (target * 0.65f)
        return (smoothed * 100f).roundToLong().toFloat() / 100f
    }
    
    private fun updateFaceOnSpeechEnd() {
        // Just reset, the expression was already set before speaking
    }
    
    private fun updateExpressionFromResponse(response: String) {
        val lowerResponse = response.lowercase()
        
        val expression = when {
            lowerResponse.contains("feliz") || lowerResponse.contains("jeje") || 
            lowerResponse.contains("ja ja") || lowerResponse.contains("😊") -> 
                Expression.HAPPY
            
            lowerResponse.contains("sorprendido") || lowerResponse.contains("wow") || 
            lowerResponse.contains("😮") -> 
                Expression.SURPRISED
            
            lowerResponse.contains("pensando") || lowerResponse.contains("interesante") || 
            lowerResponse.contains("déjame") || lowerResponse.contains("considerar") -> 
                Expression.THINKING
            
            lowerResponse.contains("triste") || lowerResponse.contains("malo") || 
            lowerResponse.contains("😢") -> 
                Expression.SAD
            
            lowerResponse.contains("enojado") || lowerResponse.contains("molesto") || 
            lowerResponse.contains("😠") -> 
                Expression.ANGRY
            
            lowerResponse.contains("😄") || lowerResponse.contains("excited") || 
            lowerResponse.contains("emocionado") -> 
                Expression.EXCITED
            
            else -> Expression.HAPPY
        }
        
        updateFace(expression)
    }
    
    fun updateFace(expression: Expression) {
        currentExpression = expression
        val duration = 300L // Animación suave
        
        when (expression) {
            Expression.HAPPY -> {
                tvStatus.text = "😊 Happy"
                animateEyeTransform(1f, 1f, 0f)
                animateColorChange(getColor(R.color.textPrimary))
                animateMouth(R.drawable.mouth_happy, getColor(R.color.textPrimary), duration)
            }
            Expression.EXCITED -> {
                tvStatus.text = "🤩 Excited"
                animateEyeTransform(1.4f, 1.4f, 0f)
                animateColorChange(getColor(R.color.buttonOrange))
                animateMouth(R.drawable.mouth_excited, getColor(R.color.buttonOrange), duration)
                // Efecto de rebote
                ivLeftEye.animate().scaleX(1.5f).scaleY(1.5f).setDuration(100)
                    .withEndAction {
                        ivLeftEye.animate().scaleX(1.4f).scaleY(1.4f).setDuration(100).start()
                    }
                ivRightEye.animate().scaleX(1.5f).scaleY(1.5f).setDuration(100)
                    .withEndAction {
                        ivRightEye.animate().scaleX(1.4f).scaleY(1.4f).setDuration(100).start()
                    }
            }
            Expression.SURPRISED -> {
                tvStatus.text = "😮 Surprised"
                // Animación de sorpresa rápida
                animateEyeTransform(1.6f, 1.6f, 0f)
                animateColorChange(getColor(R.color.buttonBlue))
                animateMouth(R.drawable.mouth_surprised, getColor(R.color.buttonBlue), 150L)
            }
            Expression.THINKING -> {
                tvStatus.text = "🤔 Thinking"
                // Ojos asimétricos pensando
                ivLeftEye.animate()
                    .scaleX(0.9f).scaleY(0.7f).rotation(15f)
                    .setDuration(duration).start()
                ivRightEye.animate()
                    .scaleX(1.1f).scaleY(1f).rotation(-10f)
                    .setDuration(duration).start()
                animateColorChange(getColor(R.color.colorAccent))
                animateMouth(R.drawable.mouth_thinking, getColor(R.color.colorAccent), duration)
            }
            Expression.SAD -> {
                tvStatus.text = "😢 Sad"
                // Ojos caídos
                ivLeftEye.animate()
                    .scaleX(1f).scaleY(0.8f).rotation(-20f)
                    .setDuration(duration).start()
                ivRightEye.animate()
                    .scaleX(1f).scaleY(0.8f).rotation(20f)
                    .setDuration(duration).start()
                animateColorChange(getColor(R.color.buttonBlue))
                animateMouth(R.drawable.mouth_sad, getColor(R.color.buttonBlue), duration)
            }
            Expression.ANGRY -> {
                tvStatus.text = "😠 Angry"
                // Ojos enfadados estrechos
                ivLeftEye.animate()
                    .scaleX(0.8f).scaleY(0.5f).rotation(-25f)
                    .setDuration(200).start()
                ivRightEye.animate()
                    .scaleX(0.8f).scaleY(0.5f).rotation(25f)
                    .setDuration(200).start()
                animateColorChange(getColor(R.color.buttonRed))
                animateMouth(R.drawable.mouth_angry, getColor(R.color.buttonRed), 200L)
            }
            Expression.SLEEPING -> {
                tvStatus.text = "😴 Sleeping"
                // Ojos cerrados suavemente
                ivLeftEye.animate()
                    .scaleX(1.1f).scaleY(0.15f).rotation(180f)
                    .setDuration(500).start()
                ivRightEye.animate()
                    .scaleX(1.1f).scaleY(0.15f).rotation(180f)
                    .setDuration(500).start()
                animateColorChange(getColor(R.color.textSecondary))
                animateMouth(R.drawable.mouth_sleeping, getColor(R.color.textSecondary), 500L)
            }
        }
    }
    
    private fun animateEyeTransform(scaleX: Float, scaleY: Float, rotation: Float) {
        val duration = 300L
        ivLeftEye.animate()
            .scaleX(scaleX).scaleY(scaleY).rotation(rotation)
            .setDuration(duration).start()
        ivRightEye.animate()
            .scaleX(scaleX).scaleY(scaleY).rotation(rotation)
            .setDuration(duration).start()
    }
    
    private fun animateColorChange(color: Int) {
        ivLeftEye.setColorFilter(color)
        ivRightEye.setColorFilter(color)
    }
    
    private fun animateMouth(drawable: Int, color: Int, duration: Long) {
        ivMouth.alpha = 0f
        ivMouth.setImageResource(drawable)
        ivMouth.setColorFilter(color)
        ivMouth.animate().alpha(1f).setDuration(duration).start()
    }
    
    private fun resetEyeTransforms() {
        ivLeftEye.scaleX = 1f
        ivLeftEye.scaleY = 1f
        ivLeftEye.rotation = 0f
        ivRightEye.scaleX = 1f
        ivRightEye.scaleY = 1f
        ivRightEye.rotation = 0f
    }
    
    private fun startBlinking() {
        blinkRunnable = object : Runnable {
            override fun run() {
                if (!isSpeaking && currentExpression != Expression.SLEEPING) {
                    // Doble parpadeo ocasional
                    val doubleBlinkChance = (1..10).random()
                    
                    performBlink()
                    
                    if (doubleBlinkChance > 8) {
                        // Doble parpadeo
                        handler.postDelayed({
                            if (!isSpeaking) performBlink()
                        }, 200)
                    }
                }
                
                // Random blink interval (2-6 seconds)
                handler.postDelayed(this, (2000..6000).random().toLong())
            }
        }
        handler.postDelayed(blinkRunnable!!, 3000)
    }
    
    private fun performBlink() {
        val currentScaleX = ivLeftEye.scaleX
        val currentScaleY = ivLeftEye.scaleY
        val currentRotation = ivLeftEye.rotation
        
        // Blink más natural
        ivLeftEye.animate()
            .scaleY(0.08f)
            .setDuration(80)
            .withEndAction {
                ivLeftEye.animate().scaleY(currentScaleY).setDuration(80).start()
            }
        
        ivRightEye.animate()
            .scaleY(0.08f)
            .setDuration(80)
            .withEndAction {
                ivRightEye.animate().scaleY(currentScaleY).setDuration(80).start()
            }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        blinkRunnable?.let { handler.removeCallbacks(it) }
        stopMouthAnimation()
        if (::textToSpeech.isInitialized) {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
    }
    
    override fun onBackPressed() {
        super.onBackPressed()
    }
}
